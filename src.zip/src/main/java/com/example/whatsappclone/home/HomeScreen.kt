package com.example.whatsappclone.home

import android.annotation.SuppressLint
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.whatsappclone.MainActivity
import com.example.whatsappclone.MainActivity.Companion.person
import com.example.whatsappclone.PersonDetails

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(nav : NavController){

    val items = mutableListOf<navState>(
        navState(title =  "Account",
           selectedIcon =  Icons.Filled.Person,
            unselectedIcon = Icons.Outlined.Person
            ),
        navState(title =  "Location",
           selectedIcon =  Icons.Filled.LocationOn,
            unselectedIcon = Icons.Outlined.LocationOn
            ),
        navState(title =  "Calls",
           selectedIcon =  Icons.Filled.Call,
            unselectedIcon = Icons.Outlined.Call
            )
    )
    var bottomnavState by rememberSaveable {
        mutableStateOf(0)
    }
    Scaffold (
        floatingActionButton = {
                FloatingActionButton(onClick = {
                    nav.navigate(route = "community")
                }) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add")
                }
        },
        topBar = {
            TopAppBar(title = {
                Text(text = "WhatsappClone",
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 20.sp)
            },
                actions = {
                    IconButton(onClick = { /*TODO*/ }) {
                        Icon(imageVector = Icons.Default.Email, contentDescription = "MoreVert")
                    }
                    IconButton(onClick = { /*TODO*/ }) {
                        Icon(imageVector = Icons.Default.MoreVert, contentDescription = "Email")
                    }
                })
        },
        bottomBar = {
            NavigationBar {
            items.forEachIndexed { index, navState ->
                    NavigationBarItem(selected = bottomnavState == index,
                        onClick = { bottomnavState = index },
                        icon = {
                            Icon(imageVector = if(bottomnavState == index) navState.selectedIcon else navState.unselectedIcon,
                                contentDescription = navState.title)
                        },
                        label = {
                            Text(text = navState.title)
                        }
                    )
                }
            }

        },

        content = {contentPadding ->
            Column(modifier = Modifier
                .padding(contentPadding)
                .fillMaxSize()) {
                personItem(person = person)
                Spacer(modifier = Modifier.height(4.dp))
                }

        }
    )
}

@Composable
fun ProfileAndPersonInfo(person: PersonDetails) {
    Column (modifier = Modifier.fillMaxSize().clickable {
        
    }) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
                Image(
                    painterResource(id = person.image),
                    contentScale = ContentScale.Crop, contentDescription = "Profile",
                    modifier = Modifier
                        .weight(3f)
                        .size(72.dp)
                        .aspectRatio(1f, matchHeightConstraintsFirst = true)
                        .clip(CircleShape)
                )
            Column(modifier = Modifier.weight(7f)) {
                Text(
                    text = person.name,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = person.message,
                    overflow = TextOverflow.Ellipsis,
                    maxLines = 1,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
        Spacer(modifier = Modifier.height(23.dp))
    }
}

@Composable
fun personItem(person: List<PersonDetails>){
    LazyColumn{
            items(MainActivity.person){index ->
                ProfileAndPersonInfo(person = index)
            }
    }
}


