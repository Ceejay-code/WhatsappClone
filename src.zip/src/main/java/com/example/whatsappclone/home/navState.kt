package com.example.whatsappclone.home

import androidx.compose.ui.graphics.vector.ImageVector

data class navState(
    val title : String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)
