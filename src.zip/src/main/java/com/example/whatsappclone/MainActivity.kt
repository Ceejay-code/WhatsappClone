package com.example.whatsappclone

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.rememberNavController
import com.example.whatsappclone.navHost.navHost
import com.example.whatsappclone.ui.theme.WhatsappCloneTheme

class MainActivity : ComponentActivity() {
    companion object {
        val person = mutableListOf<PersonDetails>(
            PersonDetails(R.drawable.cj, "Ceejay-code","I am the developer :)"),
            PersonDetails(R.drawable.god, "Isaiah 60:22","When the time is right, I the lord will make it happen"),
            PersonDetails(R.drawable.nike, "Nike ","Just do it"),
            PersonDetails(R.drawable.nelson, "Nelson Mandela ","It always seems impossible until it's done"),
            PersonDetails(R.drawable.tony, "Tony Robbins ","Don't watch the clock,do what it does"),
            PersonDetails(R.drawable.ellen, "Ellen DeGeneres","Make it happen"),
            PersonDetails(R.drawable.godins, "Seth Godins ","Just start"),
            PersonDetails(R.drawable.kevin, "Kevin Hart","Finish what you started"),
            PersonDetails(R.drawable.trock, "The Rock ","Keep pushing"),
            PersonDetails(R.drawable.steve, "Steve Jobs","The only way to do great work is to love what you do"),
            PersonDetails(R.drawable.theo, "Theodore Roosevelt","Believe you can and you're halfway there"),
            PersonDetails(R.drawable.lewis, "C.S Lewis","You are never to old to set another goal or to dream a new dream"),
        )
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WhatsappCloneTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black
                ) {
                    navHost()
                }
            }
        }
    }
}

