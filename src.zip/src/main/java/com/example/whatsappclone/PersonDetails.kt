package com.example.whatsappclone

import androidx.annotation.DrawableRes

data class PersonDetails(
   @DrawableRes val image : Int,
    val name : String,
    val message : String
)
